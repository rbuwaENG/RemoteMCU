#!/bin/bash
echo "RemoteMCU Host Agent"
echo ""
echo "Starting agent..."
python3 src/host_agent.py --token YOUR_TOKEN_HERE
