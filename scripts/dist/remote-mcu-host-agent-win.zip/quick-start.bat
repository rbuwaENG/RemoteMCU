@echo off
echo RemoteMCU Host Agent
echo.
echo Starting agent...
python src\host_agent.py --token YOUR_TOKEN_HERE
pause
